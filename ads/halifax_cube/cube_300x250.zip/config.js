AdScript.define('config', [], function() {
    return {
        preloads: {},
        dimensions: {"animate":false,"pushDown":false,"sidekick":false,"slider":false,"direction":{"width":"right","height":"bottom"},"collapsed":{"width":"300px","height":"250px"}},
        debug: {"fps":true,"boundingBoxes":true},
        hd: true
    };
});
