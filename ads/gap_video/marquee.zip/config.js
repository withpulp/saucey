AdScript.define('config', [], function() {
    return {
        preloads: {},
        dimensions: {"animate":true,"pushDown":true,"sidekick":false,"slider":false,"direction":{"width":"right","height":"bottom"},"collapsed":{"width":"1290px","height":"195px"},"expanded":{"width":"1290px","height":"599px"}},
        debug: {"fps":true,"boundingBoxes":true},
        hd: false
    };
});
